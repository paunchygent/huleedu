"""
Event models for HuleEdu microservices.
"""

from .base_event_models import BaseEventData, EventTracker, ProcessingUpdate
from .batch_coordination_events import (
    BatchContentProvisioningCompletedV1,
    BatchEssaysReady,
    BatchEssaysRegistered,
    BatchPipelineCompletedV1,
    BatchReadinessTimeout,
    ExcessContentProvisionedV1,
)
from .cj_assessment_events import (
    CJAssessmentCompletedV1,
    CJAssessmentFailedV1,
    ELS_CJAssessmentRequestV1,
)
from .class_events import (
    ClassCreatedV1,
    EssayStudentAssociationUpdatedV1,
    StudentCreatedV1,
)
from .client_commands import ClientBatchPipelineRequestV1
from .els_bos_events import ELSBatchPhaseOutcomeV1
from .envelope import EventEnvelope
from .essay_lifecycle_events import EssaySlotAssignedV1
from .file_events import EssayContentProvisionedV1, EssayValidationFailedV1
from .file_management_events import (
    BatchFileAddedV1,
    BatchFileRemovedV1,
)
from .llm_provider_events import LLMComparisonResultV1, TokenUsage
from .nlp_events import (
    StudentMatchSuggestion,
)
from .resource_consumption_events import ResourceConsumptionV1
from .spellcheck_models import (
    SpellcheckMetricsV1,
    SpellcheckPhaseCompletedV1,
    SpellcheckRequestedDataV1,
    SpellcheckResultDataV1,
    SpellcheckResultV1,
)
from .validation_events import (
    StudentAssociation,
    StudentAssociationConfirmation,
    StudentAssociationsConfirmedV1,
    ValidationTimeoutProcessedV1,
)

__all__ = [
    "BaseEventData",
    "BatchContentProvisioningCompletedV1",
    "BatchEssaysRegistered",
    "BatchEssaysReady",
    "BatchFileAddedV1",
    "BatchFileRemovedV1",
    "BatchPipelineCompletedV1",
    "BatchReadinessTimeout",
    "CJAssessmentCompletedV1",
    "CJAssessmentFailedV1",
    "ClassCreatedV1",
    "ClientBatchPipelineRequestV1",
    "ELS_CJAssessmentRequestV1",
    "ELSBatchPhaseOutcomeV1",
    "EssayAuthorMatchSuggestedV1",
    "EssayContentProvisionedV1",
    "EssaySlotAssignedV1",
    "EssayStudentAssociationUpdatedV1",
    "EssayStudentMatchingRequestedV1",
    "EssayValidationFailedV1",
    "EventEnvelope",
    "EventTracker",
    "ExcessContentProvisionedV1",
    "LLMComparisonResultV1",
    "ProcessingUpdate",
    "SpellcheckMetricsV1",
    "SpellcheckPhaseCompletedV1",
    "SpellcheckRequestedDataV1",
    "SpellcheckResultDataV1",
    "SpellcheckResultV1",
    "ResourceConsumptionV1",
    "StudentAssociation",
    "StudentAssociationConfirmation",
    "StudentAssociationsConfirmedV1",
    "StudentCreatedV1",
    "StudentMatchSuggestion",
    "TokenUsage",
    "ValidationTimeoutProcessedV1",
]
