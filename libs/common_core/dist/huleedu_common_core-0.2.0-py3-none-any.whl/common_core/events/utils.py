"""
DEPRECATED MODULE - Functions moved to huleedu_service_libs.event_utils

This module has been deprecated. Import functions directly from:
huleedu_service_libs.event_utils

This separation maintains proper architectural boundaries between
contracts (common_core) and implementations (service_libs).
"""
