from .batch_registration import BatchRegistrationRequestV1

__all__ = [
    "BatchRegistrationRequestV1",
]

