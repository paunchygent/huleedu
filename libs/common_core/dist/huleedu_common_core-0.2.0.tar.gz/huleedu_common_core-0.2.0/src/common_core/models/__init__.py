"""Common core models."""

from .error_models import ErrorDetail

__all__ = ["ErrorDetail"]
